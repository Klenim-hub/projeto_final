const express = require('express');
const router = express.Router();
const db = require("../db");

// Rota de cadastro
router.post('/cadastro', (req, res) => {
  const { email, senha, tipo, nome, crm, especialidade, data_nascimento } = req.body;

  if (!email || !senha || !tipo || !nome) {
    return res.status(400).send("Campos obrigatórios faltando.");
  }

  if (tipo === 'medico' && (!crm || !especialidade)) {
    return res.status(400).send("CRM e especialidade são obrigatórios para médicos.");
  }

  db.run(
    'INSERT INTO usuarios (email, senha, tipo, nome, crm, especialidade, data_nascimento) VALUES (?, ?, ?, ?, ?, ?, ?)',
    [
      email,
      senha,
      tipo,
      nome,
      tipo === 'medico' ? crm : null,
      tipo === 'medico' ? especialidade : null,
      data_nascimento || null
    ],
    function (err) {
      if (err) {
        if (err.message.includes("UNIQUE constraint failed: usuarios.email")) {
          return res.status(409).send("E-mail já cadastrado.");
        }
        console.error("Erro ao inserir usuário:", err);
        return res.status(500).send("Erro ao cadastrar usuário.");
      }

      res.status(201).send("Usuário cadastrado com sucesso!");
    }
  );
});

// Rota de login
router.post("/login", (req, res) => {
  const { email, senha } = req.body;

  if (!email || !senha) {
    return res.status(400).send("Preencha todos os campos.");
  }

  db.get(
    "SELECT * FROM usuarios WHERE email = ? AND senha = ?",
    [email, senha],
    (err, usuario) => {
      if (err) {
        console.error(err);
        return res.status(500).send("Erro no servidor.");
      }
      if (!usuario) {
        return res.status(401).send("Usuário ou senha inválidos.");
      }

      res.json({
        id: usuario.id,
        nome: usuario.nome,
        tipo: usuario.tipo
      });
    }
  );
});

module.exports = router;