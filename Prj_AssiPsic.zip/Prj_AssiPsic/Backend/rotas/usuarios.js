const express = require('express');
const router = express.Router();
const db = require("../db");

// Listar todos os médicos (nome e especialidade)
router.get("/medicos", (req, res) => {
  db.all("SELECT id, nome, especialidade FROM usuarios WHERE tipo = 'medico'", [], (err, rows) => {
    if (err) {
      console.error(err);
      return res.status(500).send("Erro ao buscar médicos.");
    }
    res.json(rows);
  });
});

// Listar usuários por tipo
router.get("/usuarios", (req, res) => {
  const tipo = req.query.tipo;

  if (!tipo) return res.status(400).send("Tipo de usuário não especificado.");

  db.all(
    "SELECT id, nome, crm, especialidade, data_nascimento FROM usuarios WHERE tipo = ?",
    [tipo],
    (err, rows) => {
      if (err) {
        console.error(err);
        return res.status(500).send("Erro ao buscar usuários.");
      }
      res.json(rows);
    }
  );
});

module.exports = router;