const express = require('express');
const router = express.Router();
const db = require("../db");

// Enviar nova mensagem
router.post("/", (req, res) => {
  const { remetente_id, destinatario_id, conteudo } = req.body;

  if (!remetente_id || !destinatario_id || !conteudo) {
    return res.status(400).send("Campos obrigatórios faltando.");
  }

  const query = `
    INSERT INTO mensagens (remetente_id, destinatario_id, conteudo, data_envio)
    VALUES (?, ?, ?, datetime('now'))
  `;

  db.run(query, [remetente_id, destinatario_id, conteudo], function (err) {
    if (err) {
      console.error("Erro ao enviar mensagem:", err);
      return res.status(500).send("Erro ao enviar mensagem.");
    }

    res.status(201).json({ id: this.lastID });
  });
});

// Listar mensagens por usuário
router.get("/", (req, res) => {
  const { usuario_id } = req.query;

  let query = "SELECT * FROM mensagens";
  const params = [];

  if (usuario_id) {
    query += " WHERE remetente_id = ? OR destinatario_id = ?";
    params.push(usuario_id, usuario_id);
  }

  query += " ORDER BY data_envio DESC";

  db.all(query, params, (err, rows) => {
    if (err) {
      console.error("Erro ao buscar mensagens:", err);
      return res.status(500).send("Erro ao buscar mensagens.");
    }

    res.json(rows);
  });
});

module.exports = router;