const sqlite3 = require("sqlite3").verbose();
const db = new sqlite3.Database("banco.db");

// Criação das tabelas, se ainda não existirem
db.serialize(() => {
  // Tabela de usuários (pacientes e médicos)
  db.run(`
    CREATE TABLE IF NOT EXISTS usuarios (
      id INTEGER PRIMARY KEY AUTOINCREMENT, 
      email TEXT UNIQUE NOT NULL, 
      senha TEXT NOT NULL, 
      tipo TEXT CHECK(tipo IN ('paciente', 'medico')) NOT NULL,
      nome TEXT NOT NULL,
      crm TEXT,
      especialidade TEXT,
      data_nascimento TEXT
    )
  `);

  // Tabela de mensagens (com campo 'conteudo' correto)
  db.run(`
    CREATE TABLE IF NOT EXISTS mensagens (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      remetente_id INTEGER NOT NULL,
      destinatario_id INTEGER NOT NULL,
      conteudo TEXT NOT NULL,
      data_envio DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY(remetente_id) REFERENCES usuarios(id),
      FOREIGN KEY(destinatario_id) REFERENCES usuarios(id)
    )
  `);

  console.log("Banco de dados pronto (sem apagar registros existentes).");
});

module.exports = db;