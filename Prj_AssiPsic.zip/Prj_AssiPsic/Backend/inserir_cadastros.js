const db = require("./db");

// Inserir paciente
db.run(
  `INSERT INTO usuarios (email, senha, tipo, nome, crm, especialidade, data_nascimento)
   VALUES (?, ?, ?, ?, ?, ?, ?)`,
  ["paciente@email.com", "123456", "paciente", "João Paciente", null, null, "1995-04-10"],
  function (err) {
    if (err) {
      console.error("Erro ao inserir paciente:", err.message);
    } else {
      console.log("Paciente inserido com sucesso!");
    }
  }
);

// Inserir médico
db.run(
  `INSERT INTO usuarios (email, senha, tipo, nome, crm, especialidade, data_nascimento)
   VALUES (?, ?, ?, ?, ?, ?, ?)`,
  ["medico@email.com", "123456", "medico", "Dra. Ana Médica", "CRM12345", "Psicologia", "1980-08-25"],
  function (err) {
    if (err) {
      console.error("Erro ao inserir médico:", err.message);
    } else {
      console.log("Médico inserido com sucesso!");
    }
  }
);