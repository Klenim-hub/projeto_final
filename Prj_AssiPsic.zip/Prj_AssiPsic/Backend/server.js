const express = require("express");
const cors = require("cors");
const path = require("path");
const db = require("./db");

const app = express();
const PORT = 3000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, "../public")));

// Rotas
const authRoutes = require("./rotas/auth");
const usuariosRoutes = require("./rotas/usuarios");
const mensagensRoutes = require("./rotas/mensagens");

app.use("/api", authRoutes);
app.use("/api", usuariosRoutes);
app.use("/api/mensagens", mensagensRoutes);

// Rota para buscar nome do usuário por ID
app.get("/api/usuarios/:id", (req, res) => {
  const id = req.params.id;
  db.get("SELECT nome FROM usuarios WHERE id = ?", [id], (err, row) => {
    if (err) {
      console.error(err);
      return res.status(500).send("Erro ao buscar usuário.");
    }
    if (!row) return res.status(404).send("Usuário não encontrado.");
    res.json(row);
  });
});

// Iniciar servidor
app.listen(PORT, () => {
  console.log(`Servidor rodando em http://localhost:${PORT}`);
});
