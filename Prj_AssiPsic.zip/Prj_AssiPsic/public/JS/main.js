document.addEventListener('DOMContentLoaded', () => {
  async function enviarFormulario(e, tipo) {
    e.preventDefault();

    const dados = {
      nome: document.getElementById('nome').value,
      email: document.getElementById('email').value,
      senha: document.getElementById('senha').value,
      data_nascimento: document.getElementById('data_nascimento').value,
      tipo: tipo
    };

    // Se for médico, adiciona campos específicos
    if (tipo === "medico") {
      dados.crm = document.getElementById('crm').value;
      dados.especialidade = document.getElementById('especialidade').value;
    }

    try {
      const resposta = await fetch('http://localhost:3000/api/cadastro', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(dados)
      });

      const texto = await resposta.text();
      alert(texto);
    } catch (erro) {
      console.error(`Erro ao cadastrar ${tipo}:`, erro);
      alert("Erro no cadastro");
    }
  }

  // Escuta o envio do formulário de médicos
  document.getElementById('form-medico')?.addEventListener('submit', (e) =>
    enviarFormulario(e, "medico")
  );

  // Escuta o envio do formulário de pacientes
  document.getElementById('form-paciente')?.addEventListener('submit', (e) =>
    enviarFormulario(e, "paciente")
  );
});